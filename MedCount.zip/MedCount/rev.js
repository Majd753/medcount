function Patient(name, insuranceName, insuranceClass, id, amount, clinic, doctor, medicine, medicineCode) {
    this.name = name;
    this.insuranceName = insuranceName;
    this.insuranceClass = insuranceClass;
    this.id = id;
    this.amount = amount;
    this.clinic = clinic;
    this.doctor = "Dr." + doctor;
    this.medicine = medicine;
    this.medicineCode = medicineCode;
  }

let patient1 = new Patient("Moh", "Buba", "A", 123456, 5.75, "ENT", "John", "Panadol", "5-288-99");
let patient2 = new Patient("Sal", "Buba", "B", 234567, 300, "neurology", "Sam", "Fevadol", "53-212-97");
let patient3 = new Patient("George", "NCCI",  "A", 345678, 8.05, "nutrition", "Saleh", "Fevadol Plus","53-212-97" );
let patient4 = new Patient("Moh", "NCCI", "C", 456789, 800, "ophthalmology", "Basil", "Panadol", "53-212-97");

let supplier = {
    entry: 21020103,
    type: "credit"
};

let inventory = {
    entry: 11030101,
    type: "debit",
};

let vatIn = {
    entry: 11040108,
    type: "debit"
};

let receiveable = {
    entry: 11020101,
    type: "debit"
};

let pharmacy = {
    entry: 31010140,
    type: "credit"
};

let vatOut = {
    entry: 21030306,
    type: "credit"
};

function processInvoiceRevenue(p) {
    let recEntry = receiveable.entry;
    let insuranceName = p.insuranceName;
    let insuranceClass = p.insuranceClass;
    pharmacy.revenue = p.amount/1.15;
    vatOut.vat = p.amount- (p.amount/1.15);
    let totalAmount = vatOut.vat + pharmacy.revenue;
    
    console.log("Receivable Entry: " + recEntry + " Insurance Name and Class: " + insuranceName +
    ": " + insuranceClass + " Pharmacy Revenue: " + pharmacy.revenue + " Vat " + vatOut.vat + 
    " Total Amount: " + totalAmount)

    let array = [recEntry, insuranceName, insuranceClass, pharmacy.revenue, vatOut.vat, totalAmount];

    let table = document.getElementById("tableRev");

    let row = table.insertRow();
    for (let i = 0; i < array.length; i++) {
       let cell = row.insertCell();
       cell.textContent = array[i];
       
    }

 
 }

 processInvoiceRevenue(patient3);

 fetch('https://64b2616938e74e386d550b3c.mockapi.io/api/v1/patients')
.then(res => res.json())
.then(json => {
    json.forEach(e => {
        let patient5 = new Patient(e.name, e.insuranceName, e.insuranceClass, e.id, e.amount, e.clinic, e.doctor, e.medicine, e.medicineCode)
        processInvoiceRevenue(patient5);
    });
})