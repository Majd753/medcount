function Patient(name, insuranceName, insuranceClass, id, amount, clinic, doctor, medicine, medicineCode) {
    this.name = name;
    this.insuranceName = insuranceName;
    this.insuranceClass = insuranceClass;
    this.id = id;
    this.amount = amount;
    this.clinic = clinic;
    this.doctor = "Dr." + doctor;
    this.medicine = medicine;
    this.medicineCode = medicineCode;
  }

let patient1 = new Patient("Moh", "Buba", "A", 123456, 5.75, "ENT", "John", "Panadol", "5-288-99");
let patient2 = new Patient("Sal", "Buba", "B", 234567, 300, "neurology", "Sam", "Fevadol", "53-212-97");
let patient3 = new Patient("George", "NCCI",  "A", 345678, 8.05, "nutrition", "Saleh", "Fevadol Plus","53-212-97" );
let patient4 = new Patient("Moh", "NCCI", "C", 456789, 800, "ophthalmology", "Basil", "Panadol", "53-212-97");

function Medicine(name, code, price, qty) {
    this.name = name;
    this.code = code;
    this.price = price;
    this.qty = qty;
}

let medicine1 = new Medicine("Panadol", "5-288-99", 4, 150);
let medicine2 = new Medicine("Fevadol Plus", "53-212-97", 6, 110);

let supplier = {
    entry: 21020103,
    type: "credit"
};

let inventory = {
    entry: 11030101,
    type: "debit",
};

let vatIn = {
    entry: 11040108,
    type: "debit"
};

let receiveable = {
    entry: 11020101,
    type: "debit"
};

let pharmacy = {
    entry: 31010140,
    type: "credit"
};

let vatOut = {
    entry: 21030306,
    type: "credit"
};
// فاتورة المشتريات
function processInvoicePurchase(m) {
    let code = m.code;
    let name = m.name;
    let price = m.price;
    let qty = m.qty
    let finalAmount = (qty*price);
    let vatSolo = finalAmount*0.15;
    let amountVat = (finalAmount *0.15) + finalAmount;
    console.log("code: " + code + " name: " + name + " price for 1 piece: " + price + " Quantity: "
     + qty + " Final Amount Without Vat: " + finalAmount + " Vat: " + vatSolo + 
     " Final Amount with Vat: " + amountVat)

    let table = document.getElementById("table");

     let array = [code, name, price, qty, finalAmount, vatSolo, amountVat]; 

     let row = table.insertRow();
     for (let i = 0; i < array.length; i++) {
        let cell = row.insertCell();
        cell.textContent = array[i];
        
     }


}

 processInvoicePurchase(medicine2);
 processInvoicePurchase(medicine1);

 fetch('https://64b2616938e74e386d550b3c.mockapi.io/api/v1/medicine')
.then(res => res.json())
.then(json => {
    json.forEach(e => {
        let medicine3 = new Medicine(e.name, e.code, e.price, e.qty)
        processInvoicePurchase(medicine3);
    });
})